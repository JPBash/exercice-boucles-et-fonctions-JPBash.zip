// Wrapper pour les tests qui requièrent ../utils/copy-file
module.exports = require('../../utils/copy-file');
