
    for (let i = 10; i >= 1; i--) {
      console.log(i);
    }
  }
  
  // Exporter la fonction pour les tests
  module.exports = compteARebours;
  

 module.exports = {
    compteARebours,
  };