// Énoncé : Créez une fonction nommée direBonjour qui affiche "Bonjour le monde" dans la console.
/*
  Énoncé :
  Créez une fonction nommée `direBonjour` qui affiche "Bonjour le monde" dans la console.

  Signature attendue :
    function direBonjour() -> void

  Remarque : cette version est un placeholder pour l'exercice. L'étudiant doit remplacer
  la fonction par son implémentation. Le placeholder lève une erreur explicite pour
  indiquer que le code n'est pas encore implémenté.
*/
function direBonjour() {
  // Exercice non implémenté : l'étudiant doit afficher "Bonjour le monde".
  // Placeholder neutre : ne fait rien et retourne undefined.
}

// Ne pas modifier la ligne ci-dessous
module.exports = { direBonjour }

// Resolution attendue

function direBonjour() {
  console.log("Bonjour le monde");
}   
// ne pas modifier la ligne ci-dessous
module.exports = { direBonjour }  