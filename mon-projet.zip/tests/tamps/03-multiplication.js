
  // et retourne le résultat de leur multiplication.
  
  function multiplication(a, b) {
    return a * b;
  }
  module.exports= multiplication;
  
  

 module.exports = {
    multiplication,
  };