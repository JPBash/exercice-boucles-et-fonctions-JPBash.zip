function direBonjour() {
  console.log("Bonjour le monde");
}

// Exporter la fonction sous forme nommée
exports.direBonjour = direBonjour;
