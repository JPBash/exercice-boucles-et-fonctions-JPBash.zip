function saluer(nom) {
  if (nom) {
    console.log("Bonjour, " + nom);
  } else {
    console.log("Bonjour");
  }
}
