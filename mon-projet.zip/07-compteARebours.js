function compteARebours() {
  for (let i = 10; i >= 1; i--) {
    console.log(i);
  }
  console.log("Décollage !"); 
}
