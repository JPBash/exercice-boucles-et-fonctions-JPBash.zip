// Resolution attendue
function direBonjour() {
  console.log("Bonjour le monde");
}

